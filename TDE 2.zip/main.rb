=begin


#Questão 1 - EASY https://exercism.org/tracks/ruby/exercises/microwave


puts "Digite o tempo em segundos:"

  tempo = gets.chomp.to_i

  hora = tempo/3600
  resto = tempo % 3600
  minuto = resto/60
  segundo = resto % 60

print hora,":",minuto,":",segundo

=end




=begin


#Questão 2 - EASY https://exercism.org/tracks/ruby/exercises/two-fer


puts "Digite um nome:"

nome = gets.chomp

  if (nome == "")
  puts 'Um para você, um para mim.'
  else
  puts "Um para #{nome}, um para mim."

end

=end




=begin


#Questão 3 - EASY https://exercism.org/tracks/ruby/exercises/raindrops


puts "Digite um número:"

  numero = gets.chomp.to_i

  if (numero%3 == 0 && numero%5 == 0 && numero%7 ==       0)
    puts 'PlingPlangPlong'
  elsif (numero%3 == 0 && numero%5 == 0 )
    puts 'PlingPlang'
  elsif (numero%3 == 0 && numero%7 == 0)
    puts 'PlingPlong'
  elsif (numero%5 == 0 && numero%7 == 0)
    puts 'PlangPlong'
  elsif (numero%3 == 0)
    puts 'Pling'
  elsif (numero%5 == 0)
    puts 'Plang'
  elsif (numero%7 == 0)
    puts 'Plong'
  else 
    puts numero
    
  end

=end




=begin


#Questão 4 - EASY https://exercism.org/tracks/ruby/exercises/leap


puts "Digite um ano para saber se ele é bissexto:"

  ano = gets.chomp.to_i

  if (ano % 100 == 0 && ano % 400 == 0)
    puts "Sim, esse ano é bissexto"
  elsif (ano % 4 == 0)
    puts "Sim, esse ano é bissexto"
  else
    puts "Não, esse ano não é bissexto"

  end

=end




=begin


#Questão 5 - EASY https://exercism.org/tracks/ruby/exercises/space-age


puts "Digite os segundos:"

  idade = gets.chomp.to_i

  idade_terrestre = idade/31557600
  idade_mercuriana = idade_terrestre/0.24
  idade_venusiana = idade_terrestre/0.61
  idade_marciana = idade_terrestre/1.88
  idade_jupteriana = idade_terrestre/11.86
  idade_saturniana = idade_terrestre/29.44
  idade_uraniana = idade_terrestre/84.01
  idade_netuniana = idade_terrestre/164.79

  puts "Essa idade em segundos corresponde a #{idade_mercuriana.round(2)} ano(s) mercuriano(s)"

  puts "Essa idade em segundos corresponde a #{idade_venusiana.round(2)} ano(s) venusiano(s)"

  puts "Essa idade em segundos corresponde a #{idade_terrestre.round(2)} ano(s) terrestre(s)"

  puts "Essa idade em segundos corresponde a #{idade_marciana.round(2)} ano(s) marciano(s)"

  puts "Essa idade em segundos corresponde a #{idade_jupteriana.round(2)} ano(s) jupteriano(s)"

  puts "Essa idade em segundos corresponde a #{idade_saturniana.round(2)} ano(s) saturniano(s)"

  puts "Essa idade em segundos corresponde a #{idade_uraniana.round(2)} ano(s) uraniano(s)"

  puts "Essa idade em segundos corresponde a #{idade_netuniana.round(2)} ano(s) netuniano(s)"

=end




=begin


#Questão 6 - Médio https://exercism.org/tracks/ruby/exercises/sum-of-multiples


puts "Digite um número:"
  numero = gets.chomp.to_i

puts "Agora digite dois números que você queira saber a soma de seus múltiplos:"

  x = gets.chomp.to_i
  y = gets.chomp.to_i
  somaxy = 0
  
  puts "---------------------------"

  for i in 1..numero-1
    if i%x == 0 || i%y == 0
      puts "#{i} é multiplo de #{x} ou de #{y}"
        somaxy = somaxy + i
      end
    end

  puts "\nA soma dos múltiplos de #{x} e #{y} entre 0 e #{numero} é #{somaxy}"

=end




=begin


#Questão 7 - Médio https://exercism.org/tracks/ruby/exercises/collatz-conjecture


puts "Digite um número:"
  numero = gets.chomp.to_i
  cont = 0

  while numero > 1 do
    cont = cont+1
    
    if numero == 1
      
    elsif numero%2 == 0
      numero = numero/2
  
    else
      numero = 3*numero+1

    end
  end

puts "Para chegar até 1 precisou-se passar por #{cont} passos"

=end




=begin


#Questão 8 #Questão do URI https://www.beecrowd.com.br/judge/pt/problems/view/1015


puts "Forneça os valores:"

x1= gets.chomp.to_f
x2= gets.chomp.to_f
y1= gets.chomp.to_f
y2= gets.chomp.to_f

distancia = (x2-x1)**2 + (y2-y1)**2
raiz = distancia**0.5

puts "A distância de x para y é #{raiz.round(4)}"
 
=end




=begin


#Questão 9 #Questão do URI https://www.beecrowd.com.br/judge/pt/runs/code/27618478


puts "Digite 3 números:"

a = gets.chomp.to_i
b = gets.chomp.to_i
c = gets.chomp.to_i

  if a>b && a>c
    puts ("#{a} eh o maior")
  elsif b>a && b>c
    puts ("#{b} eh o maior")
  else
    puts ("#{c} eh o maior")

end

=end




=begin


#Questão 10 #Questão do URI https://www.beecrowd.com.br/judge/pt/problems/view/1018


puts "Digite o valor em dinheiro:"

dinheiro = gets.chomp.to_i

  a = dinheiro/100
  b = dinheiro % 100
  c = b/50
  d = b % 50
  e = d/20
  f = d % 20
  g = f/10
  h = f % 10
  i = h/5
  j = h % 5
  k = j/2
  l = j % 2

   puts "#{dinheiro}"
   puts "#{a} nota(s) de R$ 100,00\n"
   puts "#{c} nota(s) de R$ 50,00\n"
   puts "#{e} nota(s) de R$ 20,00\n"
   puts "#{g} nota(s) de R$ 10,00\n"
   puts "#{i} nota(s) de R$ 5,00\n"
   puts "#{k} nota(s) de R$ 2,00\n"
   puts "#{l} nota(s) de R$ 1,00\n"

end

=end




=begin


#Questão 11 #Questão do URI https://www.beecrowd.com.br/judge/pt/problems/view/1037


puts "Digite um núemro:"

numero = gets.chomp.to_f

int = [0...25,25...50,50...75,75...100]

if numero >= 0 && numero <=25
  puts "Intervalo (#{int[0]})"

elsif numero > 25 && numero <=50
  puts "Intervalo (#{int[1]})"

elsif numero > 50 && numero <= 75
  puts "Intervalo (#{int[2]})"

elsif numero > 75 && numero <= 100
  puts "Intervalo (#{int[3]})"

else 
  puts "Fora de intervalo"

end

=end




=begin


#Questão 12 - EASY https://exercism.org/tracks/ruby/exercises/triangle


puts "Digite as medidas do triângulo:"

a = gets.chomp.to_i
b = gets.chomp.to_i
c = gets.chomp.to_i

if (a+b < c) || (a+c < b) || (b+c < a)
  puts "As medidas não formam um triângulo"
elsif (a == b) && (b == c) && (c == a)
  puts "Esse triângulo é Equilátero"
elsif (a == b) || (a == c) || (b == c)
 puts "Esse triângulo é Isóceles"
else
  print "Esse triângulo é Escaleno"

end

=end




=begin


#Questão 13 #Questão do URI https://www.beecrowd.com.br/judge/pt/problems/view/1114


puts "Digite sua senha:"

senha = gets.chomp.to_i

  while senha != 2002 do
  
  puts "\nSenha Inválida"
  puts "\nDigite a senha correta:"
  senha = gets.chomp.to_i
  
  end

  puts "\nAcesso Permitido"

=end
